function corredor() {
if(document.getElementById('infor').value!="") {
document.getElementById('infor').value="";
document.getElementById('campo2').value="";
document.getElementById('campo3').value="";
}
}